<?php
class Krish_Shopbybrand_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
     $this->loadLayout(array('default'));
     
        $_headBlock = $this->getLayout()->getBlock('head');
        if($_headBlock)
        {
            
            $brandId = $_REQUEST['brand'];
            
            $product = Mage::getModel('catalog/product');
            $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                    ->setEntityTypeFilter($product->getResource()->getTypeId())
                    ->addFieldToFilter('attribute_code', Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'))
                    ->load(false);
            
            $attributes = $attributes->getFirstItem()->setEntity($product->getResource());
            $manufacturers = $attributes->getSource()->getAllOptions(false);
            foreach($manufacturers as $k=>$v) {
                if($v['value']==$brandId)                
                {
                    $_brand_name = $v['label'];
                    
                    $_brand_name = substr($_brand_name , 0 , strpos($_brand_name , '(')-1);
                    
                    
                    break;
                }    
            }
            
            
            
            #;
            
            if($brandId > 0)
            {
                $_headBlock->setTitle("Power Medical Supplies: " . $_brand_name);
                $_headBlock->setDescription("Power Medical Supplies Online offers quality medical supply by " . $_brand_name);
            }
            
            
        }
     
     $this->renderLayout();
    }
}
