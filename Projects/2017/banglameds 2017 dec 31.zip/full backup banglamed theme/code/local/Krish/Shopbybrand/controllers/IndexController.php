<?php
class Krish_Shopbybrand_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
     $this->loadLayout(array('default'));
     
        $_headBlock = $this->getLayout()->getBlock('head');
        if($_headBlock)
        {
            
            $brandId = $_REQUEST['brand'];
            
            $product = Mage::getModel('catalog/product');
            $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                    ->setEntityTypeFilter($product->getResource()->getTypeId())
                    ->addFieldToFilter('attribute_code', Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'))
                    ->load(false);
            
            $attributes = $attributes->getFirstItem()->setEntity($product->getResource());
            $manufacturers = $attributes->getSource()->getAllOptions(false);
            foreach($manufacturers as $k=>$v) {
                if($v['value']==$brandId)                
                {
                    $_brand_name = $v['label'];
                    
                    $_brand_name = substr($_brand_name , 0 , strpos($_brand_name , '(')-1);
                    
                    
                    break;
                }    
            }
            
            
            
            #;
            
            if($brandId > 0)
            {
                $_headBlock->setTitle("banglameds " . $_brand_name);
                $_headBlock->setDescription("banglameds by " . $_brand_name);
            }
            
            
        }
     
     $this->renderLayout();
    }
    
    protected function _prepareLayout() {
        parent::_prepareLayout();
        $pager = $this->getLayout()->createBlock('page/html_pager', 'custom.pager');
         //Now you can get 4 items in a page.
        $pager->setCollection($this->getCollection());
        $pager->setAvailableLimit(array(4=>4)); 
        $this->setChild('pager', $pager);
        $this->getCollection()->load();
        return $this;
    }
                        
                        
}
