<?php

class Krish_Shopbybrand_Block_Shopbybrand extends Mage_Catalog_Block_Product_List {

     public function __construct() {
        parent::__construct();
        /*
        $collection = Mage::getModel('catalog/product')->getCollection();
        
        
        $collection->getSelect()->limit(4);
        #echo $collection->getSelect()->__toString(); exit;
        $this->setCollection($collection);
        */              
    }

    
    public function getAllBrands() {
        $product = Mage::getModel('catalog/product');
        $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setEntityTypeFilter($product->getResource()->getTypeId())
                ->addFieldToFilter('attribute_code', Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'))
                ->load(false);
        $attribute = $attributes->getFirstItem()->setEntity($product->getResource());

        $manufacturers = $attribute->getSource()->getAllOptions(false);
        
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                        ->setCodeFilter(Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'))
                        ->getFirstItem();

        
        
        /*The following code block commented by faroque*/
        /*
        $brandlogo = Mage::getModel('brandlogo/option');
        
        if($brandlogo) {
            foreach($manufacturers as $k=>$m) {
            
            $attributeOptionSingle = $brandlogo->load($m['value']);
            
            $manufacturers[$k]['logo'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'manufacturers/'.$attributeOptionSingle->getImagePath();
            }
        }*/
        
        
        return $manufacturers;
    }
    
    public function getBrandById($brandId) {
        $product = Mage::getModel('catalog/product');
        $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setEntityTypeFilter($product->getResource()->getTypeId())
                ->addFieldToFilter('attribute_code', Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'))
                ->load(false);
        
        $attributes = $attributes->getFirstItem()->setEntity($product->getResource());
        $manufacturers = $attributes->getSource()->getAllOptions(false);
        foreach($manufacturers as $k=>$v) {
            if($v['value']==$brandId)
                return $v;
        }
        
    }
    
    protected $_defaultToolbarBlock = 'catalog/product_list_toolbar';

    /**
     * Product Collection
     *
     * @var Mage_Eav_Model_Entity_Collection_Abstract
     */
    protected $_productCollection;

    /**
     * Retrieve loaded category collection
     *
     * @return Mage_Eav_Model_Entity_Collection_Abstract
     */
    protected function _getProductCollection()
    {
        //get all products of a brand
        if (is_null($this->_productCollection)) {
            $collection = Mage::getModel('catalog/product')->getCollection();
            $brandId = Mage::app()->getRequest()->getParam('brand');
            $collection
                ->addAttributeToFilter(Mage::getStoreConfig('shopbybrand/shopbybrand_group/brand_attribute'), array('eq' => $brandId))
                ->addAttributeToSelect(Mage::getSingleton('catalog/config')->getProductAttributes())
                ->addMinimalPrice()
                ->addFinalPrice()
                ->addTaxPercents();
                
                
                
            
            Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);
            Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($collection);
            $this->setCollection($collection);
            $this->_productCollection = $collection;
        }
        return $this->_productCollection;
    }


    /**
     * Get catalog layer model
     *
     * @return Mage_Catalog_Model_Layer
     */
    public function getLayer()
    {
        $layer = Mage::registry('current_layer');
        if ($layer) {
            return $layer;
        }
        return Mage::getSingleton('catalog/layer');
    }

    /**
     * Retrieve loaded category collection
     *
     * @return Mage_Eav_Model_Entity_Collection_Abstract
     */
    public function getLoadedProductCollection()
    {
        return $this->_getProductCollection();
    }

    /**
     * Retrieve current view mode
     *
     * @return string
     */
    public function getMode()
    {
        return $this->getChild('toolbar')->getCurrentMode();
    }

    /**
     * Need use as _prepareLayout - but problem in declaring collection from
     * another block (was problem with search result)
     */
    protected function _beforeToHtml()
    {
        $toolbar = $this->getToolbarBlock();

        // called prepare sortable parameters
        $collection = $this->_getProductCollection();

        // use sortable parameters
        if ($orders = $this->getAvailableOrders()) {
            $toolbar->setAvailableOrders($orders);
        }
        if ($sort = $this->getSortBy()) {
            $toolbar->setDefaultOrder($sort);
        }
        if ($dir = $this->getDefaultDirection()) {
            $toolbar->setDefaultDirection($dir);
        }
        if ($modes = $this->getModes()) {
            $toolbar->setModes($modes);
        }

        // set collection to toolbar and apply sort
        $toolbar->setCollection($collection);

        $this->setChild('toolbar', $toolbar);
        Mage::dispatchEvent('catalog_block_product_list_collection', array(
            'collection' => $this->_getProductCollection()
        ));

        $this->_getProductCollection()->load();

        return parent::_beforeToHtml();
    }

    /**
     * Retrieve Toolbar block
     *
     * @return Mage_Catalog_Block_Product_List_Toolbar
     */
    public function getToolbarBlock()
    {
        if ($blockName = $this->getToolbarBlockName()) {
            if ($block = $this->getLayout()->getBlock($blockName)) {
                return $block;
            }
        }
        $block = $this->getLayout()->createBlock($this->_defaultToolbarBlock, microtime());
        return $block;
    }

    /**
     * Retrieve additional blocks html
     *
     * @return string
     */
    public function getAdditionalHtml()
    {
        return $this->getChildHtml('additional');
    }

    /**
     * Retrieve list toolbar HTML
     *
     * @return string
     */
    public function getToolbarHtml()
    {
        return $this->getChildHtml('toolbar');
    }

    public function setCollection($collection)
    {
        $this->_productCollection = $collection;
        return $this;
    }

    public function addAttribute($code)
    {
        $this->_getProductCollection()->addAttributeToSelect($code);
        return $this;
    }

    public function getPriceBlockTemplate()
    {
        return $this->_getData('price_block_template');
    }

    /**
     * Retrieve Catalog Config object
     *
     * @return Mage_Catalog_Model_Config
     */
    protected function _getConfig()
    {
        return Mage::getSingleton('catalog/config');
    }

    /**
     * Prepare Sort By fields from Category Data
     *
     * @param Mage_Catalog_Model_Category $category
     * @return Mage_Catalog_Block_Product_List
     */
    public function prepareSortableFieldsByCategory($category) {
        if (!$this->getAvailableOrders()) {
            $this->setAvailableOrders($category->getAvailableSortByOptions());
        }
        $availableOrders = $this->getAvailableOrders();
        if (!$this->getSortBy()) {
            if ($categorySortBy = $category->getDefaultSortBy()) {
                if (!$availableOrders) {
                    $availableOrders = $this->_getConfig()->getAttributeUsedForSortByArray();
                }
                if (isset($availableOrders[$categorySortBy])) {
                    $this->setSortBy($categorySortBy);
                }
            }
        }

        return $this;
    }

    public function getPrice()
    {
        return $this->getProduct()->getPrice();
    }

    public function getFinalPrice()
    {
        if (!isset($this->_finalPrice[$this->getProduct()->getId()])) {
            $this->_finalPrice[$this->getProduct()->getId()] = $this->getProduct()->getFinalPrice();
        }
        return $this->_finalPrice[$this->getProduct()->getId()];
    }

    public function getPriceHtml($product)
    {
        $this->setTemplate('catalog/product/price.phtml');
        $this->setProduct($product);
        return $this->toHtml();
    }
 

    public function getCollection(){
        $collection = Mage::getModel('catalog/product')->getCollection();
        return $collection;                
            
            
    }

    
    public function Test()
    {
        echo 'test';
    }    
   
    public function getPagerHtml() {
        return $this->getChildHtml('pager');
    }

    protected function _prepareLayout() {
        parent::_prepareLayout();
        $limit = Mage::app()->getRequest()->getParam('limit');
        
        $allowedValues = Mage::getStoreConfig('catalog/frontend/grid_per_page_values'); 
        $grid_per_page_values = explode(",", $allowedValues);
        $i = 0;
        foreach($grid_per_page_values as $gridperpage){
            if($i == 0){
                $grid_per_page_result_first = $gridperpage ;
            }
            $grid_per_page_result[$gridperpage] = $gridperpage;
            $i++;
        }
        
        if(!$limit){
            $limit = $grid_per_page_result_first;
        }
        
        
        
        $pager = $this->getLayout()->createBlock('page/html_pager', 'custom.pager');
         //Now you can get 4 items in a page.
        $pager->setLimit($limit)->setCollection($this->_getProductCollection());
        $pager->setAvailableLimit($grid_per_page_result);       
        $this->setChild('pager', $pager);
        $this->_getProductCollection()->load();
        return $this;
    }

}
