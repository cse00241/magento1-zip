<?php
class Mirasvit_Misspell_Helper_Code extends Mirasvit_MstCore_Helper_Code
{
    protected $k = "YM0WOU7NJT";
    protected $s = "SSU";
    protected $l = "27414";
    protected $v = "2.3.4";
    protected $b = "1388";
    protected $d = "luontaistukku.fi";
}
