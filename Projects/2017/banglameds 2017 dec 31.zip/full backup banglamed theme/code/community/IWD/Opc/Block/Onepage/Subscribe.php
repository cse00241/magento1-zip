<?php

class IWD_Opc_Block_Onepage_Subscribe extends Mage_Core_Block_Template
{

}
