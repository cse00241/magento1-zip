<?php

class IWD_Opc_Block_Onepage_Payment_Giftcard_Opc extends IWD_GiftCardAccount_Block_Onepage_Payment_Giftcard
{

}