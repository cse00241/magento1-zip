<?php

class IWD_Opc_Block_Onepage_Payment_Paypal_Express_Button extends Mage_Paypal_Block_Express_Shortcut
{

}
