<?php

class IWD_Opc_Block_Onepage_Payment_GeneBraintree_Js extends Gene_Braintree_Block_Js
{

}