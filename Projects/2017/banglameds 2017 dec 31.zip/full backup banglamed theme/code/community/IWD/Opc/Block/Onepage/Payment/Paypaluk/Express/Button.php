<?php

class IWD_Opc_Block_Onepage_Payment_Paypaluk_Express_Button extends Mage_PaypalUk_Block_Express_Shortcut
{

}