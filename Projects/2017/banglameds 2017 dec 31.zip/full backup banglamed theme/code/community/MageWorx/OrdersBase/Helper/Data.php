<?php
/**
 * MageWorx
 * MageWorx Order Base Extension
 * 
 * @category   MageWorx
 * @package    MageWorx_OrdersBase
 * @copyright  Copyright (c) 2016 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_OrdersBase_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}