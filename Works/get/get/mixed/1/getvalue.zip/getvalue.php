<?PHP
function readCSV($csvFile){
    $file_handle = fopen($csvFile, 'r');
    while (!feof($file_handle) ) {
        $line_of_text[] = fgetcsv($file_handle, 1024);
    }
    fclose($file_handle);
    return $line_of_text;
}


// Set path to CSV file
$csvFile = 'test.csv';

$csv = readCSV($csvFile);
/*
echo '<pre>';
print_r(array_filter($csv));
echo '</pre>';
*/
foreach(array_filter($csv) as $v){
	//echo $v['email'];
}


$csv = array();
// prepare a file called customers.csv with email, firstname, lastname
if( ($handle = fopen('test.csv', "r")) !== FALSE) {
   $rowCounter = 0;
   while (($rowData = fgetcsv($handle, 0, ",")) !== FALSE) {
       if( 0 === $rowCounter) {
           $headerRecord = $rowData;
       } else {
           foreach( $rowData as $key => $value) {
               $csv[ $rowCounter - 1][ $headerRecord[ $key] ] = $value;  
           }
       }
       $rowCounter++;
   }
   fclose($handle);
}
$x = 0;
foreach ($csv as $customer) {
	echo $customer['email'];
}
?>