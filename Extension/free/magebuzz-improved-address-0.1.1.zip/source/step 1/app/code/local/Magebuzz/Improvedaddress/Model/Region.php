<?php
/*
* Copyright (c) 2015 www.magebuzz.com 
*/
class Magebuzz_Improvedaddress_Model_Region extends Mage_Core_Model_Abstract {
	public function _construct() {
		$this->_init('improvedaddress/region');
	}
}