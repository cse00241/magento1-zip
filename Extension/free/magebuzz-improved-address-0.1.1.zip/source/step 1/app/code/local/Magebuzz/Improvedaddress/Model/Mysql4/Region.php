<?php
/*
* Copyright (c) 2015 www.magebuzz.com 
*/
class Magebuzz_Improvedaddress_Model_Mysql4_Region extends Magebuzz_Improvedaddress_Model_Resource_Region {
	
}