<?php
class Trenza_Deliverytime_IndexController extends Mage_Core_Controller_Front_Action
{
    public function _indexAction()
    {
		//$model = Mage::getModel("deliverytime/deliverytime");    
        for($x=2 ; $x<8 ; $x++):    
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('8')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('9')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('10')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('11')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('12')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('13')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('14')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('15')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('16')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('17')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('18')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('19')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('20')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('21')->save();
            Mage::getModel("deliverytime/deliverytime")->setDay($x)->setHr('22')->save();
        endfor;
    }
}
