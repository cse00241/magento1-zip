<?php

require_once 'Mage/Checkout/controllers/OnepageController.php';

class Trenza_Deliverytime_OnepageController extends Mage_Checkout_OnepageController
{
    public function saveShippingMethodAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        if ($this->isFormkeyValidationOnCheckoutEnabled() && !$this->_validateFormKey()) {
            return;
        }

        if ($this->getRequest()->isPost()) {
            
            $_delivery_date = $this->getRequest()->getPost('delivery_date');
            Mage::getSingleton('core/session')->setTrenzaDeliveryDate($_delivery_date);
            
            $_delivery_hr = $this->getRequest()->getPost('delivery_hr');
            Mage::getSingleton('core/session')->setTrenzaDeliveryHour($_delivery_hr);
            
            $_delivery_day = $this->getRequest()->getPost('delivery_day');
            Mage::getSingleton('core/session')->setTrenzaDeliveryDay($_delivery_day);
            
            
            $data = $this->getRequest()->getPost('shipping_method', '');
            $result = $this->getOnepage()->saveShippingMethod($data);
            // $result will contain error data if shipping method is empty
            if (!$result) {
                Mage::dispatchEvent(
                    'checkout_controller_onepage_save_shipping_method',
                     array(
                          'request' => $this->getRequest(),
                          'quote'   => $this->getOnepage()->getQuote()));
                $this->getOnepage()->getQuote()->collectTotals();
                $this->_prepareDataJSON($result);

                $result['goto_section'] = 'payment';
                $result['update_section'] = array(
                    'name' => 'payment-method',
                    'html' => $this->_getPaymentMethodsHtml()
                );
            }
            $this->getOnepage()->getQuote()->collectTotals()->save();
            $this->_prepareDataJSON($result);
        }
    }
}
