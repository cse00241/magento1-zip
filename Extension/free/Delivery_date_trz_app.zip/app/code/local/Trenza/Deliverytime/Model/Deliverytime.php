<?php

class Trenza_Deliverytime_Model_Deliverytime extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        parent::_construct(); 
        $this->_init("deliverytime/deliverytime");

    }

}
	 