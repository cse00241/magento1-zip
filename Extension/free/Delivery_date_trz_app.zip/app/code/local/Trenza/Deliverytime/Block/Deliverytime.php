<?php

class Trenza_Deliverytime_Block_deliverytime extends Mage_Checkout_Block_Onepage
{
    
}