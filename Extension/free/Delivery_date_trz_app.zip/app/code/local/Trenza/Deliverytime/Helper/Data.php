<?php
class Trenza_Deliverytime_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getDays()
    {
        
        $day1 = mktime(0, 0, 0, date("m")  , date("d") , date("Y"));
        $day2  = mktime(0, 0, 0, date("m")  , date("d")+1, date("Y"));
        $day3  = mktime(0, 0, 0, date("m")  , date("d")+2, date("Y"));
        $day4  = mktime(0, 0, 0, date("m")  , date("d")+3, date("Y"));
        $day5  = mktime(0, 0, 0, date("m")  , date("d")+4, date("Y"));
        $day6  = mktime(0, 0, 0, date("m")  , date("d")+5, date("Y"));
        $day7  = mktime(0, 0, 0, date("m")  , date("d")+6, date("Y"));
        
        
        $day_arr[0]['date'] = date("d/m/Y" , $day1);
        $day_arr[0]['text'] = "Today [".date("d M" , $day1)."]";
        
        $day_arr[1]['date'] = date("d/m/Y" , $day2);
        $day_arr[1]['text'] = "Tomorrow [".date("d M" , $day2)."]";
        
        $day_arr[2]['date'] = date("d/m/Y" , $day3);
        $day_arr[2]['text'] = date("l" , $day3) ." [".date("d M" , $day3)."]";
        
        $day_arr[3]['date'] = date("d/m/Y" , $day4);
        $day_arr[3]['text'] = date("l" , $day4) ." [".date("d M" , $day4)."]";
        
        $day_arr[4]['date'] = date("d/m/Y" , $day5);
        $day_arr[4]['text'] = date("l" , $day5) ." [".date("d M" , $day5)."]";
        
        $day_arr[5]['date'] = date("d/m/Y" , $day6);
        $day_arr[5]['text'] = date("l" , $day6) ." [".date("d M" , $day6)."]";
        
        $day_arr[6]['date'] = date("d/m/Y" , $day7);
        $day_arr[6]['text'] = date("l" , $day7) ." [".date("d M" , $day7)."]";
        
        
        return $day_arr;
    }
    
    public function getDaySlot($day)
    {
        $hr_limit = 13;
        $all_slot =  Mage::getModel("deliverytime/deliverytime")->getCollection()->addFieldToFilter('day' , $day)->addFieldToFilter('orderno', array('lt' => $hr_limit))->setOrder('hr','ASC');
        
        return $all_slot;
    } 
}