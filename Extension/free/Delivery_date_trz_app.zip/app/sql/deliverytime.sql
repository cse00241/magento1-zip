-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2017 at 02:43 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bm`
--

-- --------------------------------------------------------

--
-- Table structure for table `deliverytime`
--

CREATE TABLE `deliverytime` (
  `id` int(11) NOT NULL,
  `day` tinyint(2) NOT NULL,
  `hr` tinyint(2) NOT NULL,
  `orderno` tinyint(4) NOT NULL,
  `flg` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliverytime`
--

INSERT INTO `deliverytime` (`id`, `day`, `hr`, `orderno`, `flg`) VALUES
(1, 1, 8, 0, 0),
(2, 1, 9, 0, 0),
(3, 1, 10, 15, 0),
(4, 1, 11, 0, 0),
(5, 1, 12, 0, 0),
(6, 1, 13, 0, 0),
(7, 1, 14, 0, 0),
(8, 1, 15, 0, 0),
(9, 1, 16, 0, 0),
(10, 1, 17, 0, 0),
(11, 1, 18, 0, 0),
(12, 1, 19, 0, 0),
(13, 1, 20, 0, 0),
(14, 1, 21, 0, 0),
(15, 1, 22, 0, 0),
(16, 2, 8, 0, 0),
(17, 2, 9, 0, 0),
(18, 2, 10, 0, 0),
(19, 2, 11, 0, 0),
(20, 2, 12, 0, 0),
(21, 2, 13, 0, 0),
(22, 2, 14, 0, 0),
(23, 2, 15, 0, 0),
(24, 2, 16, 0, 0),
(25, 2, 17, 0, 0),
(26, 2, 18, 0, 0),
(27, 2, 19, 0, 0),
(28, 2, 20, 0, 0),
(29, 2, 21, 0, 0),
(30, 2, 22, 0, 0),
(31, 3, 8, 0, 0),
(32, 3, 9, 0, 0),
(33, 3, 10, 0, 0),
(34, 3, 11, 0, 0),
(35, 3, 12, 0, 0),
(36, 3, 13, 0, 0),
(37, 3, 14, 0, 0),
(38, 3, 15, 0, 0),
(39, 3, 16, 0, 0),
(40, 3, 17, 0, 0),
(41, 3, 18, 0, 0),
(42, 3, 19, 0, 0),
(43, 3, 20, 0, 0),
(44, 3, 21, 0, 0),
(45, 3, 22, 0, 0),
(46, 4, 8, 0, 0),
(47, 4, 9, 0, 0),
(48, 4, 10, 0, 0),
(49, 4, 11, 0, 0),
(50, 4, 12, 0, 0),
(51, 4, 13, 0, 0),
(52, 4, 14, 0, 0),
(53, 4, 15, 0, 0),
(54, 4, 16, 0, 0),
(55, 4, 17, 0, 0),
(56, 4, 18, 0, 0),
(57, 4, 19, 0, 0),
(58, 4, 20, 0, 0),
(59, 4, 21, 0, 0),
(60, 4, 22, 0, 0),
(61, 5, 8, 0, 0),
(62, 5, 9, 0, 0),
(63, 5, 10, 0, 0),
(64, 5, 11, 0, 0),
(65, 5, 12, 0, 0),
(66, 5, 13, 0, 0),
(67, 5, 14, 0, 0),
(68, 5, 15, 0, 0),
(69, 5, 16, 0, 0),
(70, 5, 17, 0, 0),
(71, 5, 18, 0, 0),
(72, 5, 19, 0, 0),
(73, 5, 20, 0, 0),
(74, 5, 21, 0, 0),
(75, 5, 22, 0, 0),
(76, 6, 8, 0, 0),
(77, 6, 9, 0, 0),
(78, 6, 10, 0, 0),
(79, 6, 11, 0, 0),
(80, 6, 12, 0, 0),
(81, 6, 13, 0, 0),
(82, 6, 14, 0, 0),
(83, 6, 15, 0, 0),
(84, 6, 16, 0, 0),
(85, 6, 17, 0, 0),
(86, 6, 18, 0, 0),
(87, 6, 19, 0, 0),
(88, 6, 20, 0, 0),
(89, 6, 21, 0, 0),
(90, 6, 22, 0, 0),
(91, 7, 8, 0, 0),
(92, 7, 9, 0, 0),
(93, 7, 10, 0, 0),
(94, 7, 11, 0, 0),
(95, 7, 12, 0, 0),
(96, 7, 13, 0, 0),
(97, 7, 14, 0, 0),
(98, 7, 15, 0, 0),
(99, 7, 16, 0, 0),
(100, 7, 17, 0, 0),
(101, 7, 18, 0, 0),
(102, 7, 19, 0, 0),
(103, 7, 20, 0, 0),
(104, 7, 21, 0, 0),
(105, 7, 22, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deliverytime`
--
ALTER TABLE `deliverytime`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deliverytime`
--
ALTER TABLE `deliverytime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
